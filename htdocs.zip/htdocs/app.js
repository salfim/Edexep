/**
 * ملف JavaScript الرئيسي للتطبيق
 * إدارة الدردشة، التسجيل، إرسال الرسائل وتحديثها
 * الأحدث في الأسفل - الأقدم في الأعلى
 */

// ============ المتغيرات العامة ============
let refreshInterval;
let currentPage = 1;
const messagesPerPage = 30;
let isTabActive = true;
let lastMessageId = 0;

// ============ أحداث DOM عند التحميل ============
document.addEventListener('DOMContentLoaded', function() {
    // تحسين تحميل الصفحة
    setTimeout(() => {
        const loadingElements = document.querySelectorAll('.loading');
        loadingElements.forEach(el => {
            el.style.opacity = '0';
            setTimeout(() => {
                if (el.parentNode) el.parentNode.removeChild(el);
            }, 300);
        });
    }, 500);
    
    // إذا كان المستخدم مسجل الدخول، حمّل الرسائل
    if (loggedIn) {
        setTimeout(() => {
            loadMessages();
            startAutoRefresh();
            
            // أحداث إرسال الرسائل
            setupChatEvents();
            
            // أحداث الملف الشخصي والخروج
            setupUserEvents();
            
            // إعداد زر التمرير للأسفل
            setupScrollButton();
            
            // تفعيل حقل الإدخال
            const messageInput = document.getElementById('message-input');
            if (messageInput) {
                messageInput.disabled = false;
                messageInput.focus();
                messageInput.placeholder = 'اكتب رسالتك هنا... (يدعم العربية والإنجليزية)';
            }
        }, 800);
    }
    
    // أحداث نافذة المصادقة
    setupAuthEvents();
    
    // تكبير حقل النص تلقائياً
    autoResizeTextarea();
    
    // متابعة حالة التبويب
    setupTabVisibility();
    
    // إعداد ارتفاع الصفحة للمتصفحات المحمولة
    setupMobileHeight();
});

// ============ متابعة حالة التبويب ============
function setupTabVisibility() {
    document.addEventListener('visibilitychange', function() {
        isTabActive = !document.hidden;
        
        if (isTabActive) {
            // إذا عاد المستخدم للتبويب، تحديث الرسائل
            if (typeof refreshInterval !== 'undefined') {
                clearInterval(refreshInterval);
                startAutoRefresh();
            }
        } else {
            // إذا ترك التبويب، إيقاف التحديث التلقائي
            if (typeof refreshInterval !== 'undefined') {
                clearInterval(refreshInterval);
            }
        }
    });
}

// ============ إعداد ارتفاع الجوال ============
function setupMobileHeight() {
    function setFullHeight() {
        const vh = window.innerHeight * 0.01;
        document.documentElement.style.setProperty('--vh', `${vh}px`);
        
        const chatContainer = document.getElementById('chat-container');
        if (chatContainer) {
            chatContainer.style.height = window.innerHeight + 'px';
        }
    }
    
    window.addEventListener('resize', setFullHeight);
    window.addEventListener('orientationchange', setFullHeight);
    setFullHeight();
}

// ============ زر التمرير للأسفل ============
function setupScrollButton() {
    const scrollBtn = document.getElementById('scroll-to-bottom');
    const messagesContainer = document.getElementById('messages-container');
    
    if (!scrollBtn || !messagesContainer) return;
    
    // التحقق من موقع التمرير
    function checkScrollPosition() {
        const isAtBottom = isNearBottom();
        
        if (isAtBottom) {
            scrollBtn.style.opacity = '0';
            scrollBtn.style.transform = 'translateY(20px)';
            scrollBtn.style.pointerEvents = 'none';
        } else {
            scrollBtn.style.opacity = '1';
            scrollBtn.style.transform = 'translateY(0)';
            scrollBtn.style.pointerEvents = 'auto';
        }
    }
    
    // حدث التمرير
    messagesContainer.addEventListener('scroll', checkScrollPosition);
    
    // حدث النقر على الزر
    scrollBtn.addEventListener('click', function() {
        scrollToBottom();
        setTimeout(() => {
            scrollBtn.style.opacity = '0';
            scrollBtn.style.transform = 'translateY(20px)';
        }, 300);
    });
    
    // التحقق الأولي
    setTimeout(checkScrollPosition, 1000);
}

// ============ أحداث المصادقة (الدخول/التسجيل) ============
function setupAuthEvents() {
    // تبديل التبويبات
    const tabs = document.querySelectorAll('.auth-tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            // تحديث التبويبات النشطة
            tabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            // إظهار النموذج المطلوب
            document.querySelectorAll('.auth-form').forEach(form => {
                form.classList.remove('active');
            });
            document.getElementById(tabId + '-form').classList.add('active');
            
            // مسح أخطاء سابقة
            clearErrors();
        });
    });
    
    // زر تسجيل الدخول
    document.getElementById('login-btn').addEventListener('click', loginUser);
    
    // زر إنشاء حساب
    document.getElementById('signup-btn').addEventListener('click', signupUser);
    
    // السماح بالدخول بالزر Enter
    document.getElementById('login-password').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') loginUser();
    });
    
    document.getElementById('signup-password2').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') signupUser();
    });
}

// ============ تسجيل الدخول ============
async function loginUser() {
    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value;
    const errorDiv = document.getElementById('login-error');
    
    // التحقق من الحقول
    if (!username || !password) {
        showError(errorDiv, 'الرجاء ملء جميع الحقول');
        return;
    }
    
    // إظهار حالة التحميل
    const loginBtn = document.getElementById('login-btn');
    const originalText = loginBtn.textContent;
    loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الدخول...';
    loginBtn.disabled = true;
    
    try {
        const response = await fetch('login.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`
        });
        
        const data = await response.json();
        
        if (data.success) {
            // نجاح الدخول - إعادة تحميل الصفحة
            window.location.reload();
        } else {
            // فشل الدخول
            showError(errorDiv, data.message || 'اسم المستخدم أو كلمة المرور غير صحيحة');
            loginBtn.innerHTML = originalText;
            loginBtn.disabled = false;
        }
    } catch (error) {
        showError(errorDiv, 'خطأ في الاتصال بالخادم');
        console.error('Login error:', error);
        loginBtn.innerHTML = originalText;
        loginBtn.disabled = false;
    }
}

// ============ إنشاء حساب جديد ============
async function signupUser() {
    const username = document.getElementById('signup-username').value.trim();
    const displayname = document.getElementById('signup-displayname').value.trim();
    const password = document.getElementById('signup-password').value;
    const password2 = document.getElementById('signup-password2').value;
    const errorDiv = document.getElementById('signup-error');
    
    // التحقق من الحقول
    if (!username || !displayname || !password) {
        showError(errorDiv, 'الرجاء ملء جميع الحقول');
        return;
    }
    
    if (password !== password2) {
        showError(errorDiv, 'كلمتا المرور غير متطابقتين');
        return;
    }
    
    if (password.length < 6) {
        showError(errorDiv, 'كلمة المرور يجب أن تكون 6 أحرف على الأقل');
        return;
    }
    
    if (username.length < 3) {
        showError(errorDiv, 'اسم المستخدم يجب أن يكون 3 أحرف على الأقل');
        return;
    }
    
    // إظهار حالة التحميل
    const signupBtn = document.getElementById('signup-btn');
    const originalText = signupBtn.textContent;
    signupBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الإنشاء...';
    signupBtn.disabled = true;
    
    try {
        const response = await fetch('signup.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `username=${encodeURIComponent(username)}&display_name=${encodeURIComponent(displayname)}&password=${encodeURIComponent(password)}`
        });
        
        const data = await response.json();
        
        if (data.success) {
            // نجاح الإنشاء - التحويل لتبويب الدخول
            showSuccess('تم إنشاء الحساب بنجاح! يمكنك الآن تسجيل الدخول');
            
            // تبديل لتبويب الدخول
            document.querySelector('.auth-tab[data-tab="login"]').click();
            
            // تعبئة اسم المستخدم تلقائياً
            document.getElementById('login-username').value = username;
            document.getElementById('signup-username').value = '';
            document.getElementById('signup-displayname').value = '';
            document.getElementById('signup-password').value = '';
            document.getElementById('signup-password2').value = '';
        } else {
            // فشل الإنشاء
            showError(errorDiv, data.message || 'حدث خطأ أثناء إنشاء الحساب');
        }
    } catch (error) {
        showError(errorDiv, 'خطأ في الاتصال بالخادم');
        console.error('Signup error:', error);
    } finally {
        signupBtn.innerHTML = originalText;
        signupBtn.disabled = false;
    }
}

// ============ أحداث الدردشة ============
function setupChatEvents() {
    // زر إرسال الرسالة
    document.getElementById('send-btn').addEventListener('click', sendMessage);
    
    // إرسال بالزر Enter (بدون Shift)
    const messageInput = document.getElementById('message-input');
    if (messageInput) {
        messageInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });
    }
    
    // تحميل الصور
    const imageUpload = document.getElementById('image-upload');
    if (imageUpload) {
        imageUpload.addEventListener('change', function(e) {
            if (this.files && this.files[0]) {
                uploadImage(this.files[0]);
            }
        });
    }
    
    // التمرير لتحميل المزيد من الرسائل
    const messagesContainer = document.getElementById('messages-container');
    if (messagesContainer) {
        let scrollTimeout;
        messagesContainer.addEventListener('scroll', function() {
            clearTimeout(scrollTimeout);
            
            // تفعيل التحديث بعد توقف التمرير
            scrollTimeout = setTimeout(() => {
                // إذا وصل المستخدم إلى الأعلى، تحميل المزيد من الرسائل القديمة
                if (this.scrollTop === 0) {
                    loadMoreMessages();
                }
            }, 300);
        });
    }
}

// ============ إرسال رسالة نصية ============
async function sendMessage() {
    const messageInput = document.getElementById('message-input');
    if (!messageInput) return;
    
    const messageText = messageInput.value.trim();
    
    if (!messageText && !currentUploadingImage) {
        return;
    }
    
    // تعطيل الحقل مؤقتاً
    messageInput.disabled = true;
    const sendBtn = document.getElementById('send-btn');
    if (sendBtn) {
        sendBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        sendBtn.disabled = true;
    }
    
    try {
        const formData = new FormData();
        formData.append('user_id', userId);
        formData.append('message_text', messageText);
        
        if (currentUploadingImage) {
            formData.append('image', currentUploadingImage);
        }
        
        const response = await fetch('send_message.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            // مسح الحقل
            messageInput.value = '';
            messageInput.style.height = 'auto';
            currentUploadingImage = null;
            
            // إعادة تعيين زر الصورة
            const fileLabel = document.querySelector('.file-label');
            if (fileLabel) {
                fileLabel.style.background = '';
                fileLabel.querySelector('i').className = 'fas fa-image';
            }
            
            // تحديث آخر معرف رسالة
            if (data.message_id && data.message_id > lastMessageId) {
                lastMessageId = data.message_id;
            }
            
            // إضافة الرسالة فوراً للواجهة
            addMessageToUI({
                id: data.message_id,
                user_id: userId,
                display_name: userDisplayName,
                profile_image: userProfileImage,
                message_text: messageText,
                image_path: data.image_path || null,
                timestamp: new Date().toISOString()
            });
            
            // التمرير للأسفل
            scrollToBottom();
        } else {
            alert('فشل إرسال الرسالة: ' + (data.message || 'حدث خطأ'));
        }
    } catch (error) {
        console.error('Error sending message:', error);
        alert('خطأ في الاتصال بالخادم');
    } finally {
        // إعادة تفعيل الحقل
        messageInput.disabled = false;
        messageInput.focus();
        if (sendBtn) {
            sendBtn.innerHTML = '<i class="fas fa-paper-plane"></i>';
            sendBtn.disabled = false;
        }
    }
}

// ============ تحميل الصور ============
let currentUploadingImage = null;

async function uploadImage(file) {
    // التحقق من حجم الملف (5MB كحد أقصى)
    if (file.size > 5 * 1024 * 1024) {
        alert('حجم الصورة كبير جداً. الحد الأقصى هو 5MB');
        document.getElementById('image-upload').value = '';
        return;
    }
    
    // التحقق من نوع الملف
    if (!file.type.match('image.*')) {
        alert('الرجاء اختيار صورة فقط');
        document.getElementById('image-upload').value = '';
        return;
    }
    
    // عرض معاينة للصورة
    const reader = new FileReader();
    reader.onload = function(e) {
        currentUploadingImage = file;
        
        // إضافة معاينة في حقل النص
        const messageInput = document.getElementById('message-input');
        if (messageInput && !messageInput.value.includes('(صورة مرفقة)')) {
            messageInput.value += ' (صورة مرفقة)';
            autoResizeTextarea();
        }
        
        // تغيير لون زر الصورة للإشارة لوجود صورة
        const fileLabel = document.querySelector('.file-label');
        if (fileLabel) {
            fileLabel.style.background = '#00adb5';
            fileLabel.querySelector('i').className = 'fas fa-check';
        }
    };
    reader.readAsDataURL(file);
}

// ============ تحميل الرسائل ============
async function loadMessages() {
    try {
        const response = await fetch(`fetch_messages.php?page=${currentPage}&limit=${messagesPerPage}&initial=true`);
        const data = await response.json();
        
        if (data.success) {
            // إخفاء مؤشر التحميل
            const loadingEl = document.getElementById('loading-messages');
            if (loadingEl) {
                loadingEl.style.opacity = '0';
                setTimeout(() => {
                    if (loadingEl.parentNode) loadingEl.parentNode.removeChild(loadingEl);
                }, 300);
            }
            
            // تحديث آخر معرف رسالة
            if (data.last_message_id) {
                lastMessageId = data.last_message_id;
            }
            
            // عرض الرسائل (الأقدم إلى الأحدث)
            if (data.messages.length > 0) {
                // إضافة الرسائل بالترتيب الطبيعي (الأقدم أولاً، الأحدث آخراً)
                data.messages.forEach(message => {
                    addMessageToUI(message, false); // false = إضافة في الأسفل
                });
                
                // التمرير للأسفل لعرض الرسائل الأحدث
                setTimeout(scrollToBottom, 500);
            } else if (currentPage === 1) {
                // لا توجد رسائل على الإطلاق
                const container = document.getElementById('messages-container');
                if (container) {
                    container.innerHTML = `
                        <div style="text-align: center; padding: 50px; color: #888;">
                            <i class="fas fa-comments" style="font-size: 48px; margin-bottom: 20px;"></i>
                            <h3>لا توجد رسائل بعد</h3>
                            <p>كن أول من يرسل رسالة في المجموعة!</p>
                        </div>
                    `;
                }
            }
        }
    } catch (error) {
        console.error('Error loading messages:', error);
        const loadingEl = document.getElementById('loading-messages');
        if (loadingEl) {
            loadingEl.innerHTML = 
                '<i class="fas fa-exclamation-triangle"></i> خطأ في تحميل الرسائل';
        }
    }
}

// ============ تحميل المزيد من الرسائل (القديمة) ============
async function loadMoreMessages() {
    if (!isTabActive) return;
    
    const container = document.getElementById('messages-container');
    if (!container) return;
    
    const oldScrollHeight = container.scrollHeight;
    
    currentPage++;
    
    try {
        const response = await fetch(`fetch_messages.php?page=${currentPage}&limit=${messagesPerPage}`);
        const data = await response.json();
        
        if (data.success && data.messages.length > 0) {
            // تحديث آخر معرف رسالة
            if (data.last_message_id) {
                lastMessageId = data.last_message_id;
            }
            
            // إضافة الرسائل القديمة في الأعلى
            data.messages.forEach(message => {
                addMessageToUI(message, true); // true = إضافة في الأعلى
            });
            
            // الحفاظ على موضع التمرير
            const newScrollHeight = container.scrollHeight;
            container.scrollTop = newScrollHeight - oldScrollHeight;
        } else {
            currentPage--; // تراجع إذا لم تكن هناك رسائل جديدة
        }
    } catch (error) {
        console.error('Error loading more messages:', error);
        currentPage--;
    }
}

// ============ تحميل الرسائل الجديدة ============
async function loadNewMessages() {
    if (!isTabActive || lastMessageId === 0) return;
    
    try {
        const response = await fetch(`fetch_messages.php?last_message_id=${lastMessageId}`);
        const data = await response.json();
        
        if (data.success && data.new_messages && data.new_messages.length > 0) {
            // تحديث آخر معرف رسالة
            const lastNewMessage = data.new_messages[data.new_messages.length - 1];
            lastMessageId = lastNewMessage.id;
            
            // إضافة الرسائل الجديدة في الأسفل
            data.new_messages.forEach(message => {
                if (!document.getElementById(`message-${message.id}`)) {
                    addMessageToUI(message, false); // false = إضافة في الأسفل
                }
            });
            
            // إذا كان المستخدم في الأسفل، التمرير لأسفل
            if (isNearBottom()) {
                setTimeout(scrollToBottom, 100);
            }
        }
    } catch (error) {
        console.error('Load new messages error:', error);
    }
}

// ============ التحديث التلقائي ============
function startAutoRefresh() {
    let isUpdating = false;
    
    // تحديث الرسائل كل 3 ثوانٍ
    refreshInterval = setInterval(async () => {
        if (isUpdating || !isTabActive) return;
        
        try {
            isUpdating = true;
            await loadNewMessages();
        } catch (error) {
            console.error('Auto-refresh error:', error);
        } finally {
            isUpdating = false;
        }
    }, 3000);
}

// ============ إضافة رسالة للواجهة ============
function addMessageToUI(message, prepend = false) {
    const container = document.getElementById('messages-container');
    if (!container) return;
    
    // التحقق إذا كانت الرسالة موجودة مسبقاً
    if (document.getElementById(`message-${message.id}`)) {
        return;
    }
    
    // تحديث آخر معرف رسالة
    if (message.id > lastMessageId) {
        lastMessageId = message.id;
    }
    
    // إنشاء عنصر الرسالة
    const messageElement = document.createElement('div');
    messageElement.className = `message ${message.user_id == userId ? 'own' : ''}`;
    messageElement.id = `message-${message.id}`;
    messageElement.style.opacity = '0';
    
    // تأثير ظهور مختلف بناءً على المكان
    if (prepend) {
        messageElement.style.transform = 'translateY(-10px)';
    } else {
        messageElement.style.transform = 'translateY(10px)';
    }
    
    // تنسيق التاريخ
    const messageDate = new Date(message.timestamp);
    const timeString = messageDate.toLocaleTimeString('ar-SA', {
        hour: '2-digit',
        minute: '2-digit'
    });
    const dateString = messageDate.toLocaleDateString('ar-SA');
    
    // بناء محتوى الرسالة
    let imageHtml = '';
    if (message.image_path) {
        imageHtml = `<img src="${message.image_path}" alt="صورة مرفقة" class="message-image" onclick="viewImage('${message.image_path}')" loading="lazy">`;
    }
    
    messageElement.innerHTML = `
        <img src="${message.profile_image}" alt="${message.display_name}" class="message-avatar" loading="lazy">
        <div class="message-content">
            <div class="message-sender">${escapeHtml(message.display_name)}</div>
            <div class="message-text">${formatMessageText(message.message_text)}</div>
            ${imageHtml}
            <div class="message-time" title="${dateString} ${timeString}">
                <i class="far fa-clock"></i> ${timeString}
            </div>
        </div>
    `;
    
    // إضافة الرسالة
    if (prepend && container.firstChild) {
        container.insertBefore(messageElement, container.firstChild);
    } else {
        container.appendChild(messageElement);
    }
    
    // تأثير الظهور
    setTimeout(() => {
        messageElement.style.transition = 'opacity 0.3s, transform 0.3s';
        messageElement.style.opacity = '1';
        messageElement.style.transform = 'translateY(0)';
    }, 10);
}

// ============ أحداث المستخدم ============
function setupUserEvents() {
    // زر الخروج
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            if (confirm('هل أنت متأكد من تسجيل الخروج؟')) {
                window.location.href = 'logout.php';
            }
        });
    }
    
    // زر الملف الشخصي
    const profileImgBtn = document.getElementById('profile-img-btn');
    if (profileImgBtn) {
        profileImgBtn.addEventListener('click', function() {
            window.location.href = 'profile.php';
        });
    }
}

// ============ دوال مساعدة ============
function showError(errorElement, message) {
    if (!errorElement) return;
    
    errorElement.textContent = message;
    errorElement.style.display = 'block';
    setTimeout(() => {
        errorElement.style.display = 'none';
    }, 5000);
}

function showSuccess(message) {
    // إنشاء رسالة نجاح مؤقتة
    const successDiv = document.createElement('div');
    successDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #00adb5;
        color: white;
        padding: 15px 25px;
        border-radius: 10px;
        z-index: 10000;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        animation: slideIn 0.3s ease;
    `;
    successDiv.innerHTML = `<i class="fas fa-check"></i> ${message}`;
    document.body.appendChild(successDiv);
    
    setTimeout(() => {
        successDiv.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            if (successDiv.parentNode) successDiv.parentNode.removeChild(successDiv);
        }, 300);
    }, 3000);
}

function clearErrors() {
    document.querySelectorAll('.error-message').forEach(el => {
        el.style.display = 'none';
    });
}

function autoResizeTextarea() {
    const textarea = document.getElementById('message-input');
    if (!textarea) return;
    
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
}

function scrollToBottom() {
    const container = document.getElementById('messages-container');
    if (!container) return;
    
    container.scrollTop = container.scrollHeight;
}

function isNearBottom() {
    const container = document.getElementById('messages-container');
    if (!container) return false;
    
    return container.scrollHeight - container.scrollTop - container.clientHeight < 100;
}

function formatMessageText(text) {
    if (!text) return '';
    
    // استبدال الروابط
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    text = text.replace(urlRegex, url => 
        `<a href="${url}" target="_blank" style="color: #a0e7e5;">${url}</a>`
    );
    
    // استبدال الفواصل بفواصل عربية
    text = text.replace(/,/g, '،');
    
    // الهروب من HTML
    return escapeHtml(text).replace(/\n/g, '<br>');
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function viewImage(imageUrl) {
    // فتح الصورة في نافذة مشاهدتها
    const viewer = document.createElement('div');
    viewer.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.95);
        z-index: 10000;
        display: flex;
        justify-content: center;
        align-items: center;
        animation: fadeIn 0.3s ease;
    `;
    
    viewer.innerHTML = `
        <div style="position: relative;">
            <img src="${imageUrl}" style="max-width: 90vw; max-height: 90vh; border-radius: 10px;">
            <button style="position: absolute; top: -40px; right: 0; background: #ff2e63; border: none; color: white; padding: 10px 15px; border-radius: 5px; cursor: pointer;">
                <i class="fas fa-times"></i> إغلاق
            </button>
        </div>
    `;
    
    viewer.addEventListener('click', function(e) {
        if (e.target.tagName === 'BUTTON' || e.target.tagName === 'I' || !e.target.closest('div')) {
            viewer.style.animation = 'fadeOut 0.3s ease';
            setTimeout(() => {
                if (viewer.parentNode) viewer.parentNode.removeChild(viewer);
            }, 300);
        }
    });
    
    document.body.appendChild(viewer);
}

// إيقاف التحديث التلقائي عند ترك الصفحة
window.addEventListener('beforeunload', function() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
    }
});

// تكبير textarea تلقائياً
document.addEventListener('input', function(e) {
    if (e.target.id === 'message-input') {
        autoResizeTextarea();
    }
});

// إضافة أنماط للرسوم المتحركة
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    
    @keyframes fadeOut {
        from { opacity: 1; }
        to { opacity: 0; }
    }
`;
document.head.appendChild(style);

// منع التكبير على الهواتف
if ('ontouchstart' in window) {
    document.body.classList.add('touch-device');
}