<?php
session_start();
require_once 'db.php';

// تعيين رأس JSON للاستجابة
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, must-revalidate');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'غير مصرح بالوصول، يرجى تسجيل الدخول']);
    exit;
}

// إضافة تأخير بسيط للتحميل الأولي
if (isset($_GET['initial']) && $_GET['initial'] == 'true') {
    usleep(300000); // 0.3 ثانية تأخير للتحميل الأولي
}

// الحصول على معاملات الطلب
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = isset($_GET['limit']) ? intval($_GET['limit']) : 30;
$last_update = isset($_GET['last_update']) ? intval($_GET['last_update']) : 0;
$last_message_id = isset($_GET['last_message_id']) ? intval($_GET['last_message_id']) : 0;

// التحقق من صحة القيم
if ($page < 1) $page = 1;
if ($limit < 1 || $limit > 50) $limit = 30;

// حساب الإزاحة
$offset = ($page - 1) * $limit;

try {
    // إذا كان هناك last_update، جلب الرسائل الجديدة فقط
    if ($last_update > 0) {
        $timestamp = date('Y-m-d H:i:s', $last_update / 1000);
        
        $stmt = $conn->prepare("
            SELECT m.*, u.display_name, u.profile_image 
            FROM messages m 
            JOIN users u ON m.user_id = u.id 
            WHERE m.timestamp > ? 
            ORDER BY m.timestamp ASC 
            LIMIT 50
        ");
        $stmt->execute([$timestamp]);
        $new_messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'new_messages' => $new_messages,
            'count' => count($new_messages),
            'timestamp' => time()
        ]);
        exit;
    }
    
    // جلب الرسائل الجديدة فقط بناءً على last_message_id
    if ($last_message_id > 0) {
        $stmt = $conn->prepare("
            SELECT m.*, u.display_name, u.profile_image 
            FROM messages m 
            JOIN users u ON m.user_id = u.id 
            WHERE m.id > ? 
            ORDER BY m.timestamp ASC 
            LIMIT 100
        ");
        $stmt->execute([$last_message_id]);
        $new_messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'new_messages' => $new_messages,
            'count' => count($new_messages)
        ]);
        exit;
    }
    
    // جلب الرسائل مع الترحيل (الأحدث في الأسفل)
    $stmt = $conn->prepare("
        SELECT m.*, u.display_name, u.profile_image 
        FROM messages m 
        JOIN users u ON m.user_id = u.id 
        ORDER BY m.timestamp ASC 
        LIMIT ? OFFSET ?
    ");
    
    $stmt->bindValue(1, $limit, PDO::PARAM_INT);
    $stmt->bindValue(2, $offset, PDO::PARAM_INT);
    $stmt->execute();
    
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // جلب العدد الكلي للرسائل
    $countStmt = $conn->query("SELECT COUNT(*) as total FROM messages");
    $total_messages = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // الحصول على آخر معرف رسالة
    $last_id = 0;
    if (!empty($messages)) {
        $last_message = end($messages);
        $last_id = $last_message['id'];
    }
    
    echo json_encode([
        'success' => true,
        'messages' => $messages,
        'last_message_id' => $last_id,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'offset' => $offset,
            'total' => $total_messages,
            'total_pages' => ceil($total_messages / $limit)
        ]
    ]);
    
} catch (PDOException $e) {
    error_log("Fetch messages error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطأ في جلب الرسائل']);
}
?>