<?php
session_start();
require_once 'db.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// جلب بيانات المستخدم الحالي
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    session_destroy();
    header('Location: index.php');
    exit;
}

// معالجة تحديث الملف الشخصي
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $display_name = trim($_POST['display_name']);
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // تنظيف المدخلات
    $display_name = htmlspecialchars($display_name, ENT_QUOTES, 'UTF-8');
    
    // التحقق من الاسم الظاهر
    if (empty($display_name)) {
        $error = 'الاسم الظاهر لا يمكن أن يكون فارغاً';
    } elseif (strlen($display_name) < 2) {
        $error = 'الاسم الظاهر يجب أن يكون حرفين على الأقل';
    } elseif (preg_match('/[<>"\'\{\}\[\]\(\)\;]/', $display_name)) {
        $error = 'الاسم الظاهر يحتوي على رموز غير مسموحة';
    } else {
        // التحقق من كلمة المرور الحالية إذا كانت هناك محاولة لتغيير كلمة المرور
        $password_changed = false;
        
        if (!empty($current_password) || !empty($new_password) || !empty($confirm_password)) {
            // التحقق من إدخال جميع حقول كلمة المرور
            if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
                $error = 'يرجى ملء جميع حقول كلمة المرور';
            } elseif (!password_verify($current_password, $user['password'])) {
                $error = 'كلمة المرور الحالية غير صحيحة';
            } elseif (strlen($new_password) < 6) {
                $error = 'كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل';
            } elseif ($new_password !== $confirm_password) {
                $error = 'كلمتا المرور الجديدتين غير متطابقتين';
            } else {
                // تغيير كلمة المرور
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $password_changed = true;
            }
        }
        
        // معالجة رفع الصورة
        $profile_image = $user['profile_image'];
        
        if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
            $file_info = $_FILES['profile_image'];
            $file_name = $file_info['name'];
            $file_tmp = $file_info['tmp_name'];
            $file_size = $file_info['size'];
            $file_error = $file_info['error'];
            
            // الحصول على امتداد الملف
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            
            // الأنواع المسموحة
            $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            
            // التحقق من نوع الملف
            if (in_array($file_ext, $allowed_ext)) {
                // التحقق من حجم الملف (2MB كحد أقصى)
                if ($file_size <= 2 * 1024 * 1024) {
                    // إنشاء اسم فريد للملف
                    $new_file_name = 'avatar_' . $user_id . '_' . time() . '.' . $file_ext;
                    $upload_path = 'uploads/avatars/' . $new_file_name;
                    
                    // إنشاء مجلد avatars إذا لم يكن موجوداً
                    if (!file_exists('uploads/avatars/')) {
                        mkdir('uploads/avatars/', 0777, true);
                    }
                    
                    // حذف الصورة القديمة إذا لم تكن الصورة الافتراضية
                    if ($profile_image !== 'default_avatar.png' && file_exists($profile_image)) {
                        unlink($profile_image);
                    }
                    
                    // نقل الملف
                    if (move_uploaded_file($file_tmp, $upload_path)) {
                        $profile_image = $upload_path;
                    } else {
                        $error = 'فشل رفع الصورة';
                    }
                } else {
                    $error = 'حجم الصورة كبير جداً. الحد الأقصى: 2MB';
                }
            } else {
                $error = 'نوع الملف غير مسموح. المسموح: ' . implode(', ', $allowed_ext);
            }
        }
        
        // إذا لم يكن هناك خطأ، تحديث البيانات
        if (empty($error)) {
            try {
                if ($password_changed) {
                    // تحديث مع كلمة المرور
                    $stmt = $conn->prepare("UPDATE users SET display_name = ?, profile_image = ?, password = ? WHERE id = ?");
                    $result = $stmt->execute([$display_name, $profile_image, $hashed_password, $user_id]);
                } else {
                    // تحديث بدون كلمة المرور
                    $stmt = $conn->prepare("UPDATE users SET display_name = ?, profile_image = ? WHERE id = ?");
                    $result = $stmt->execute([$display_name, $profile_image, $user_id]);
                }
                
                if ($result) {
                    // تحديث بيانات الجلسة
                    $_SESSION['display_name'] = $display_name;
                    $_SESSION['profile_image'] = $profile_image;
                    
                    $success = 'تم تحديث الملف الشخصي بنجاح';
                    $user['display_name'] = $display_name;
                    $user['profile_image'] = $profile_image;
                } else {
                    $error = 'فشل تحديث البيانات';
                }
            } catch (PDOException $e) {
                error_log("Profile update error: " . $e->getMessage());
                $error = 'حدث خطأ أثناء تحديث البيانات';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الملف الشخصي - مجموعة الدردشة</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #f0f0f0;
            min-height: 100vh;
            padding: 20px;
        }
        
        .profile-container {
            max-width: 600px;
            margin: 40px auto;
            background: rgba(25, 25, 35, 0.95);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.3);
            border: 1px solid #00adb5;
        }
        
        .profile-header {
            background: rgba(0, 173, 181, 0.2);
            padding: 40px;
            text-align: center;
            border-bottom: 1px solid #00adb5;
        }
        
        .profile-header h1 {
            font-size: 28px;
            color: #a0e7e5;
            margin-bottom: 10px;
        }
        
        .profile-header p {
            color: #ccc;
            font-size: 16px;
        }
        
        .back-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(255, 46, 99, 0.2);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: background 0.3s;
        }
        
        .back-btn:hover {
            background: rgba(255, 46, 99, 0.4);
        }
        
        .profile-content {
            padding: 40px;
        }
        
        .profile-image-section {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .profile-img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            border: 5px solid #00adb5;
            margin-bottom: 20px;
            cursor: pointer;
            transition: transform 0.3s;
        }
        
        .profile-img:hover {
            transform: scale(1.05);
        }
        
        .image-upload-label {
            display: inline-block;
            background: #393e46;
            color: white;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
            margin-top: 10px;
            transition: background 0.3s;
        }
        
        .image-upload-label:hover {
            background: #00adb5;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 10px;
            color: #a0e7e5;
            font-weight: 600;
            font-size: 16px;
        }
        
        .form-group input {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid #393e46;
            border-radius: 12px;
            background: rgba(40, 40, 60, 0.9);
            color: white;
            font-size: 16px;
            unicode-bidi: plaintext;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #00adb5;
        }
        
        .form-group .info {
            font-size: 14px;
            color: #888;
            margin-top: 5px;
        }
        
        .password-section {
            background: rgba(0, 173, 181, 0.1);
            padding: 20px;
            border-radius: 12px;
            margin-top: 30px;
        }
        
        .password-section h3 {
            color: #00adb5;
            margin-bottom: 15px;
            font-size: 18px;
        }
        
        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 25px;
            font-weight: 600;
        }
        
        .alert-success {
            background: rgba(0, 173, 181, 0.2);
            border: 1px solid #00adb5;
            color: #a0e7e5;
        }
        
        .alert-error {
            background: rgba(255, 46, 99, 0.2);
            border: 1px solid #ff2e63;
            color: #ff7b9c;
        }
        
        .submit-btn {
            width: 100%;
            padding: 18px;
            background: linear-gradient(90deg, #00adb5, #006a71);
            border: none;
            border-radius: 12px;
            color: white;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: transform 0.3s;
            margin-top: 20px;
        }
        
        .submit-btn:hover {
            transform: translateY(-3px);
        }
        
        .stats-section {
            display: flex;
            justify-content: space-around;
            margin-top: 40px;
            padding-top: 30px;
            border-top: 1px solid #393e46;
        }
        
        .stat {
            text-align: center;
        }
        
        .stat-number {
            font-size: 28px;
            color: #00adb5;
            font-weight: bold;
        }
        
        .stat-label {
            font-size: 14px;
            color: #aaa;
            margin-top: 5px;
        }
        
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            
            .profile-container {
                margin: 20px auto;
            }
            
            .profile-header, .profile-content {
                padding: 25px;
            }
            
            .profile-img {
                width: 120px;
                height: 120px;
            }
            
            .stats-section {
                flex-direction: column;
                gap: 20px;
            }
        }
    </style>
</head>
<body>
    <a href="index.php" class="back-btn">
        <i class="fas fa-arrow-right"></i> العودة للدردشة
    </a>
    
    <div class="profile-container">
        <div class="profile-header">
            <h1><i class="fas fa-user-cog"></i> الملف الشخصي</h1>
            <p>تعديل معلومات حسابك الشخصي</p>
        </div>
        
        <div class="profile-content">
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data">
                <!-- قسم الصورة الشخصية -->
                <div class="profile-image-section">
                    <img src="<?php echo htmlspecialchars($user['profile_image']); ?>" 
                         alt="صورة الملف الشخصي" 
                         class="profile-img"
                         id="profile-img-preview">
                    
                    <label for="profile-image-upload" class="image-upload-label">
                        <i class="fas fa-camera"></i> تغيير الصورة الشخصية
                    </label>
                    <input type="file" 
                           id="profile-image-upload" 
                           name="profile_image" 
                           accept="image/*"
                           style="display: none;">
                </div>
                
                <!-- المعلومات الأساسية -->
                <div class="form-group">
                    <label for="username"><i class="fas fa-user"></i> اسم المستخدم</label>
                    <input type="text" 
                           id="username" 
                           value="<?php echo htmlspecialchars($user['username']); ?>" 
                           readonly
                           style="background: rgba(60, 60, 80, 0.9); cursor: not-allowed;">
                    <p class="info">لا يمكن تغيير اسم المستخدم</p>
                </div>
                
                <div class="form-group">
                    <label for="display_name"><i class="fas fa-id-card"></i> الاسم الظاهر</label>
                    <input type="text" 
                           id="display_name" 
                           name="display_name" 
                           value="<?php echo htmlspecialchars($user['display_name']); ?>"
                           required
                           placeholder="الاسم الذي سيراه الآخرون">
                    <p class="info">الاسم الذي سيظهر في الدردشة</p>
                </div>
                
                <!-- قسم تغيير كلمة المرور -->
                <div class="password-section">
                    <h3><i class="fas fa-lock"></i> تغيير كلمة المرور</h3>
                    <p class="info">اترك الحقول التالية فارغة إذا كنت لا تريد تغيير كلمة المرور</p>
                    
                    <div class="form-group">
                        <label for="current_password">كلمة المرور الحالية</label>
                        <input type="password" 
                               id="current_password" 
                               name="current_password"
                               placeholder="أدخل كلمة المرور الحالية">
                    </div>
                    
                    <div class="form-group">
                        <label for="new_password">كلمة المرور الجديدة</label>
                        <input type="password" 
                               id="new_password" 
                               name="new_password"
                               placeholder="كلمة مرور قوية (6 أحرف على الأقل)">
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">تأكيد كلمة المرور الجديدة</label>
                        <input type="password" 
                               id="confirm_password" 
                               name="confirm_password"
                               placeholder="أعد إدخال كلمة المرور الجديدة">
                    </div>
                </div>
                
                <button type="submit" class="submit-btn">
                    <i class="fas fa-save"></i> حفظ التغييرات
                </button>
            </form>
            
            <!-- إحصائيات -->
            <div class="stats-section">
                <div class="stat">
                    <?php
                    // جلب عدد رسائل المستخدم
                    $stmt = $conn->prepare("SELECT COUNT(*) as msg_count FROM messages WHERE user_id = ?");
                    $stmt->execute([$user_id]);
                    $msg_count = $stmt->fetch(PDO::FETCH_ASSOC)['msg_count'];
                    ?>
                    <div class="stat-number"><?php echo $msg_count; ?></div>
                    <div class="stat-label">عدد الرسائل</div>
                </div>
                
                <div class="stat">
                    <div class="stat-number">
                        <?php 
                        $join_date = date('Y-m-d', strtotime($user['created_at']));
                        echo $join_date;
                        ?>
                    </div>
                    <div class="stat-label">تاريخ الانضمام</div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // معاينة الصورة قبل الرفع
        document.getElementById('profile-image-upload').addEventListener('change', function(e) {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('profile-img-preview').src = e.target.result;
                };
                reader.readAsDataURL(this.files[0]);
            }
        });
        
        // فتح نافذة اختيار الصورة عند النقر على الصورة
        document.getElementById('profile-img-preview').addEventListener('click', function() {
            document.getElementById('profile-image-upload').click();
        });
        
        // تحذير عند محاولة ترك الصفحة دون حفظ
        let formChanged = false;
        const formInputs = document.querySelectorAll('input, textarea');
        
        formInputs.forEach(input => {
            input.addEventListener('input', () => {
                formChanged = true;
            });
        });
        
        window.addEventListener('beforeunload', function(e) {
            if (formChanged) {
                e.preventDefault();
                e.returnValue = 'قد تفقد التغييرات غير المحفوظة. هل أنت متأكد من المغادرة؟';
            }
        });
        
        // إلغاء تحذير الخروج عند إرسال النموذج
        document.querySelector('form').addEventListener('submit', function() {
            formChanged = false;
        });
    </script>
</body>
</html>