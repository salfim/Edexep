<?php
session_start();
require_once 'db.php';

// تعيين رأس JSON للاستجابة
header('Content-Type: application/json; charset=utf-8');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'غير مصرح بالوصول، يرجى تسجيل الدخول']);
    exit;
}

// التحقق من أن الطريقة POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'طريقة الطلب غير مسموحة']);
    exit;
}

// جلب بيانات المستخدم من الجلسة
$user_id = $_SESSION['user_id'];
$display_name = $_SESSION['display_name'];
$profile_image = $_SESSION['profile_image'];

// تهيئة المتغيرات
$message_text = '';
$image_path = null;

// معالجة النص إذا كان موجوداً
if (isset($_POST['message_text'])) {
    $message_text = trim($_POST['message_text']);
    $message_text = htmlspecialchars($message_text, ENT_QUOTES, 'UTF-8');
    $message_text = substr($message_text, 0, 2000); // تحديد الطول الأقصى
}

// معالجة الصورة المرفوعة
if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $upload_dir = 'uploads/';
    
    // إنشاء مجلد الرفع إذا لم يكن موجوداً
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    $file_info = $_FILES['image'];
    $file_name = $file_info['name'];
    $file_tmp = $file_info['tmp_name'];
    $file_size = $file_info['size'];
    $file_error = $file_info['error'];
    
    // الحصول على امتداد الملف
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    
    // الأنواع المسموحة
    $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    
    // التحقق من نوع الملف
    if (!in_array($file_ext, $allowed_ext)) {
        echo json_encode(['success' => false, 'message' => 'نوع الملف غير مسموح. المسموح: ' . implode(', ', $allowed_ext)]);
        exit;
    }
    
    // التحقق من حجم الملف (5MB كحد أقصى)
    if ($file_size > 5 * 1024 * 1024) {
        echo json_encode(['success' => false, 'message' => 'حجم الملف كبير جداً. الحد الأقصى: 5MB']);
        exit;
    }
    
    // إنشاء اسم فريد للملف
    $new_file_name = 'img_' . time() . '_' . uniqid() . '.' . $file_ext;
    $upload_path = $upload_dir . $new_file_name;
    
    // نقل الملف للمجلد المحدد
    if (move_uploaded_file($file_tmp, $upload_path)) {
        $image_path = $upload_path;
    } else {
        echo json_encode(['success' => false, 'message' => 'فشل رفع الصورة']);
        exit;
    }
}

// التحقق من وجود محتوى للرسالة (نص أو صورة)
if (empty($message_text) && empty($image_path)) {
    echo json_encode(['success' => false, 'message' => 'الرسالة لا يمكن أن تكون فارغة']);
    exit;
}

try {
    // إدراج الرسالة في قاعدة البيانات
    $stmt = $conn->prepare("INSERT INTO messages (user_id, message_text, image_path) VALUES (?, ?, ?)");
    
    $result = $stmt->execute([$user_id, $message_text, $image_path]);
    
    if ($result) {
        $message_id = $conn->lastInsertId();
        
        // جلب بيانات الرسالة المضافة
        $stmt = $conn->prepare("
            SELECT m.*, u.display_name, u.profile_image 
            FROM messages m 
            JOIN users u ON m.user_id = u.id 
            WHERE m.id = ?
        ");
        $stmt->execute([$message_id]);
        $message_data = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'message' => 'تم إرسال الرسالة بنجاح',
            'message_id' => $message_id,
            'image_path' => $image_path,
            'message_data' => $message_data
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'فشل إرسال الرسالة']);
    }
    
} catch (PDOException $e) {
    error_log("Send message error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطأ في الخادم، يرجى المحاولة لاحقاً']);
}
?>