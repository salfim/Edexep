<?php
session_start();
require_once 'db.php';

// تعيين رأس JSON للاستجابة
header('Content-Type: application/json; charset=utf-8');

// التحقق من أن الطريقة POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'طريقة الطلب غير مسموحة']);
    exit;
}

// قراءة البيانات الواردة
$data = json_decode(file_get_contents('php://input'), true);

// إذا لم تكن البيانات JSON، تحقق من form-data
if (!$data) {
    $data = $_POST;
}

// التحقق من وجود البيانات المطلوبة
$required_fields = ['username', 'display_name', 'password'];
foreach ($required_fields as $field) {
    if (!isset($data[$field]) || empty(trim($data[$field]))) {
        echo json_encode(['success' => false, 'message' => 'يرجى ملء جميع الحقول']);
        exit;
    }
}

$username = trim($data['username']);
$display_name = trim($data['display_name']);
$password = $data['password'];

// تنظيف وتعقيم المدخلات
$username = filter_var($username, FILTER_SANITIZE_STRING);
$display_name = filter_var($display_name, FILTER_SANITIZE_STRING);
$username = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
$display_name = htmlspecialchars($display_name, ENT_QUOTES, 'UTF-8');

// التحقق من صحة البيانات
if (strlen($username) < 3) {
    echo json_encode(['success' => false, 'message' => 'اسم المستخدم يجب أن يكون 3 أحرف على الأقل']);
    exit;
}

if (strlen($password) < 6) {
    echo json_encode(['success' => false, 'message' => 'كلمة المرور يجب أن تكون 6 أحرف على الأقل']);
    exit;
}

if (strlen($display_name) < 2) {
    echo json_encode(['success' => false, 'message' => 'الاسم الظاهر يجب أن يكون حرفين على الأقل']);
    exit;
}

// التحقق من أن اسم المستخدم يحتوي على أحرف مسموحة فقط (أحرف إنجليزية، أرقام، شرطة سفلية)
if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
    echo json_encode(['success' => false, 'message' => 'اسم المستخدم يجب أن يحتوي على أحرف إنجليزية، أرقام وشرطة سفلية فقط']);
    exit;
}

// التحقق من أن الاسم الظاهر لا يحتوي على رموز خطيرة
if (preg_match('/[<>"\'\{\}\[\]\(\)\;]/', $display_name)) {
    echo json_encode(['success' => false, 'message' => 'الاسم الظاهر يحتوي على رموز غير مسموحة']);
    exit;
}

try {
    // التحقق من أن اسم المستخدم غير موجود مسبقاً
    $checkStmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $checkStmt->execute([$username]);
    
    if ($checkStmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'اسم المستخدم موجود مسبقاً، يرجى اختيار اسم آخر']);
        exit;
    }
    
    // تشفير كلمة المرور
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // تحديد الصورة الشخصية الافتراضية
    $default_avatar = 'default_avatar.png';
    
    // إدراج المستخدم الجديد في قاعدة البيانات
    $insertStmt = $conn->prepare("INSERT INTO users (username, password, display_name, profile_image) VALUES (?, ?, ?, ?)");
    
    if ($insertStmt->execute([$username, $hashed_password, $display_name, $default_avatar])) {
        // جلب بيانات المستخدم الجديد
        $userId = $conn->lastInsertId();
        
        // تسجيل الدخول تلقائياً بعد إنشاء الحساب
        $_SESSION['user_id'] = $userId;
        $_SESSION['username'] = $username;
        $_SESSION['display_name'] = $display_name;
        $_SESSION['profile_image'] = $default_avatar;
        
        echo json_encode([
            'success' => true,
            'message' => 'تم إنشاء الحساب بنجاح!',
            'user' => [
                'id' => $userId,
                'username' => $username,
                'display_name' => $display_name,
                'profile_image' => $default_avatar
            ]
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'حدث خطأ أثناء إنشاء الحساب']);
    }
    
} catch (PDOException $e) {
    error_log("Signup error: " . $e->getMessage());
    
    // رسائل خطأ أكثر تفصيلاً للتطوير (يمكن إزالتها في الإنتاج)
    $error_message = 'خطأ في الخادم، يرجى المحاولة لاحقاً';
    if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
        $error_message = 'اسم المستخدم موجود مسبقاً';
    }
    
    echo json_encode(['success' => false, 'message' => $error_message]);
}
?>