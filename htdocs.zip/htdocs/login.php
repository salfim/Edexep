<?php
session_start();
require_once 'db.php';

// تعيين رأس JSON للاستجابة
header('Content-Type: application/json; charset=utf-8');

// التحقق من أن الطريقة POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'طريقة الطلب غير مسموحة']);
    exit;
}

// قراءة البيانات الواردة
$data = json_decode(file_get_contents('php://input'), true);

// إذا لم تكن البيانات JSON، تحقق من form-data
if (!$data) {
    $data = $_POST;
}

// التحقق من وجود البيانات المطلوبة
if (!isset($data['username']) || !isset($data['password'])) {
    echo json_encode(['success' => false, 'message' => 'البيانات غير مكتملة']);
    exit;
}

$username = trim($data['username']);
$password = $data['password'];

// تنظيف المدخلات
$username = filter_var($username, FILTER_SANITIZE_STRING);
$username = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');

// التحقق من عدم وجود حقول فارغة
if (empty($username) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'يرجى ملء جميع الحقول']);
    exit;
}

try {
    // البحث عن المستخدم في قاعدة البيانات
    $stmt = $conn->prepare("SELECT id, username, password, display_name, profile_image FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        // التحقق من كلمة المرور
        if (password_verify($password, $user['password'])) {
            // تخزين بيانات المستخدم في الجلسة
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['display_name'] = $user['display_name'];
            $_SESSION['profile_image'] = $user['profile_image'];
            
            // تحديث وقت آخر نشاط (يمكن إضافته لاحقاً إذا أردت)
            // $updateStmt = $conn->prepare("UPDATE users SET last_active = NOW() WHERE id = ?");
            // $updateStmt->execute([$user['id']]);
            
            echo json_encode([
                'success' => true,
                'message' => 'تم تسجيل الدخول بنجاح',
                'user' => [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'display_name' => $user['display_name'],
                    'profile_image' => $user['profile_image']
                ]
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'كلمة المرور غير صحيحة']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'اسم المستخدم غير موجود']);
    }
} catch (PDOException $e) {
    error_log("Login error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطأ في الخادم، يرجى المحاولة لاحقاً']);
}
?>