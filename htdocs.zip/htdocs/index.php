<?php
session_start();
require_once 'db.php';

// التحقق من وجود جلسة مستخدم
$logged_in = isset($_SESSION['user_id']);
$user_data = null;
if ($logged_in) {
    $stmt = $conn->prepare("SELECT id, username, display_name, profile_image FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user_data = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مجموعة دردشة موحدة</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
/* منطقة الرسائل - عرض من الأسفل إلى الأعلى */
.messages-container {
    flex: 1;
    padding: 25px;
    overflow-y: auto;
    background: rgba(15, 15, 25, 0.7);
    display: flex;
    flex-direction: column;
    gap: 15px;
    min-height: 0;
    justify-content: flex-end; /* يجعل المحتوى يبدأ من الأسفل */
}

/* الرسائل تكون في الأسفل بشكل طبيعي */
.message {
    display: flex;
    align-items: flex-start;
    gap: 15px;
    max-width: 80%;
    animation: fadeIn 0.3s ease;
    align-self: flex-start; /* الرسائل تبدأ من اليمين */
}

.message.own {
    align-self: flex-end; /* رسائلي تبدأ من اليسار */
    flex-direction: row-reverse;
}

/* إصلاح تموضع الوقت في الرسائل */
.message-time {
    font-size: 12px;
    color: #888;
    margin-top: 8px;
    text-align: left;
}

.message.own .message-time {
    text-align: right;
}

/* تحسين التمرير */
.messages-container::-webkit-scrollbar {
    width: 8px;
}

.messages-container::-webkit-scrollbar-track {
    background: rgba(0, 0, 0, 0.1);
    border-radius: 4px;
}

.messages-container::-webkit-scrollbar-thumb {
    background: #00adb5;
    border-radius: 4px;
}

.messages-container::-webkit-scrollbar-thumb:hover {
    background: #006a71;
}
/* شريط الرأس - تثبيت */
.header {
    background: rgba(25, 25, 35, 0.98);
    padding: 15px 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 2px solid #00adb5;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    position: sticky;
    top: 0;
    z-index: 100;
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
}

/* منطقة الرسائل - إصلاح */
.messages-container {
    flex: 1;
    padding: 25px;
    overflow-y: auto;
    background: rgba(15, 15, 25, 0.7);
    display: flex;
    flex-direction: column;
    gap: 15px;
    min-height: 0;
}

/* منطقة الإرسال - تثبيت */
.input-container {
    background: rgba(25, 25, 35, 0.98);
    padding: 20px 25px;
    display: flex;
    gap: 15px;
    border-top: 2px solid #393e46;
    position: sticky;
    bottom: 0;
    z-index: 99;
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
}

/* تحسين ظهور حقل الإدخال */
.message-input {
    flex: 1;
    padding: 15px 20px;
    border: 2px solid #393e46;
    border-radius: 30px;
    background: rgba(40, 40, 60, 0.95);
    color: white;
    font-size: 16px;
    resize: none;
    min-height: 50px;
    max-height: 120px;
    unicode-bidi: plaintext;
    transition: border-color 0.3s, background 0.3s;
}

.message-input:focus {
    outline: none;
    border-color: #00adb5;
    background: rgba(50, 50, 70, 0.95);
    box-shadow: 0 0 0 2px rgba(0, 173, 181, 0.2);
}

/* تحسين أداء الصور */
.message-avatar, .message-image, .profile-img {
    content-visibility: auto;
    will-change: transform;
}

/* إصلاح مشكلة التمرير على الجوال */
@media (max-width: 768px) {
    body {
        height: 100vh;
        height: -webkit-fill-available;
        overflow: hidden;
    }
    
    #chat-container {
        height: 100vh;
        height: -webkit-fill-available;
    }
    
    .messages-container {
        padding-bottom: 100px; /* مساحة لحقل الإدخال */
    }
}

/* تحسين تحميل الصفحة */
#loading-messages {
    padding: 40px;
    text-align: center;
    color: #00adb5;
    font-size: 18px;
    transition: opacity 0.3s ease;
}

/* تحسين الظهور التدريجي */
#chat-container {
    width: 100%;
    height: 100vh;
    display: flex;
    flex-direction: column;
    filter: <?php echo $logged_in ? 'blur(0px)' : 'blur(10px)'; ?>;
    transition: filter 0.5s ease, opacity 0.5s ease;
    pointer-events: <?php echo $logged_in ? 'auto' : 'none'; ?>;
    opacity: <?php echo $logged_in ? '1' : '0.7'; ?>;
}
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #f0f0f0;
            height: 100vh;
            overflow: hidden;
        }
        
        /* غرفة الدردشة المموهة */
        #chat-container {
            width: 100%;
            height: 100vh;
            display: flex;
            flex-direction: column;
            filter: <?php echo $logged_in ? 'blur(0px)' : 'blur(10px)'; ?>;
            transition: filter 0.5s ease;
            pointer-events: <?php echo $logged_in ? 'auto' : 'none'; ?>;
            opacity: <?php echo $logged_in ? '1' : '0.7'; ?>;
        }
        
        /* شريط الرأس */
        .header {
            background: rgba(25, 25, 35, 0.95);
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #00adb5;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .logo i {
            color: #00adb5;
            font-size: 28px;
        }
        
        .logo h1 {
            font-size: 24px;
            background: linear-gradient(90deg, #00adb5, #a0e7e5);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .profile-img {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #00adb5;
            cursor: pointer;
        }
        
        .display-name {
            font-size: 18px;
            font-weight: 600;
            color: #a0e7e5;
        }
        
        .logout-btn {
            background: #ff2e63;
            color: white;
            border: none;
            padding: 8px 18px;
            border-radius: 20px;
            cursor: pointer;
            font-weight: bold;
            transition: background 0.3s;
        }
        
        .logout-btn:hover {
            background: #ff4a7c;
        }
        
        /* منطقة الرسائل */
        .messages-container {
            flex: 1;
            padding: 25px;
            overflow-y: auto;
            background: rgba(15, 15, 25, 0.7);
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .message {
            display: flex;
            align-items: flex-start;
            gap: 15px;
            max-width: 80%;
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .message.own {
            align-self: flex-end;
            flex-direction: row-reverse;
        }
        
        .message-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #393e46;
        }
        
        .message-content {
            background: rgba(40, 40, 60, 0.9);
            padding: 12px 18px;
            border-radius: 18px;
            border-top-right-radius: 5px;
            max-width: 100%;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
        }
        
        .message.own .message-content {
            background: linear-gradient(135deg, #006a71, #00adb5);
            border-top-right-radius: 18px;
            border-top-left-radius: 5px;
        }
        
        .message-sender {
            font-weight: bold;
            color: #00adb5;
            margin-bottom: 5px;
            font-size: 14px;
        }
        
        .message.own .message-sender {
            color: #a0e7e5;
            text-align: right;
        }
        
        .message-text {
            font-size: 16px;
            line-height: 1.5;
            word-break: break-word;
            unicode-bidi: plaintext;
            text-align: right;
        }
        
        .message-image {
            max-width: 300px;
            max-height: 300px;
            border-radius: 12px;
            margin-top: 10px;
            border: 2px solid rgba(255, 255, 255, 0.1);
        }
        
        .message-time {
            font-size: 12px;
            color: #888;
            margin-top: 8px;
            text-align: left;
        }
        
        .message.own .message-time {
            text-align: right;
        }
        
        /* منطقة إرسال الرسالة */
        .input-container {
            background: rgba(25, 25, 35, 0.95);
            padding: 20px 25px;
            display: flex;
            gap: 15px;
            border-top: 2px solid #393e46;
        }
        
        .message-input {
            flex: 1;
            padding: 15px 20px;
            border: 2px solid #393e46;
            border-radius: 30px;
            background: rgba(40, 40, 60, 0.9);
            color: white;
            font-size: 16px;
            resize: none;
            min-height: 50px;
            max-height: 120px;
            unicode-bidi: plaintext;
        }
        
        .message-input:focus {
            outline: none;
            border-color: #00adb5;
        }
        
        .file-label {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: #393e46;
            color: white;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .file-label:hover {
            background: #00adb5;
        }
        
        .send-btn {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, #00adb5, #006a71);
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            transition: transform 0.3s;
        }
        
        .send-btn:hover {
            transform: scale(1.05);
        }
        
        /* Overlay الدخول */
        #auth-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.85);
            display: <?php echo $logged_in ? 'none' : 'flex'; ?>;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            backdrop-filter: blur(5px);
        }
        
        .auth-box {
            background: linear-gradient(145deg, #1a1a2e, #16213e);
            width: 90%;
            max-width: 450px;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
            border: 1px solid #00adb5;
        }
        
        .auth-header {
            background: rgba(0, 173, 181, 0.2);
            padding: 30px;
            text-align: center;
            border-bottom: 1px solid #00adb5;
        }
        
        .auth-header h2 {
            font-size: 28px;
            color: #a0e7e5;
            margin-bottom: 10px;
        }
        
        .auth-header p {
            color: #ccc;
        }
        
        .auth-tabs {
            display: flex;
            border-bottom: 1px solid #393e46;
        }
        
        .auth-tab {
            flex: 1;
            padding: 18px;
            text-align: center;
            background: rgba(40, 40, 60, 0.5);
            color: #aaa;
            cursor: pointer;
            font-size: 18px;
            font-weight: bold;
            transition: all 0.3s;
        }
        
        .auth-tab.active {
            background: rgba(0, 173, 181, 0.2);
            color: #00adb5;
            border-bottom: 3px solid #00adb5;
        }
        
        .auth-form {
            padding: 30px;
            display: none;
        }
        
        .auth-form.active {
            display: block;
            animation: fadeInUp 0.5s ease;
        }
        
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .input-group {
            margin-bottom: 25px;
        }
        
        .input-group label {
            display: block;
            margin-bottom: 8px;
            color: #a0e7e5;
            font-weight: 600;
        }
        
        .input-group input {
            width: 100%;
            padding: 15px;
            border: 2px solid #393e46;
            border-radius: 12px;
            background: rgba(40, 40, 60, 0.9);
            color: white;
            font-size: 16px;
            unicode-bidi: plaintext;
        }
        
        .input-group input:focus {
            outline: none;
            border-color: #00adb5;
        }
        
        .auth-btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(90deg, #00adb5, #006a71);
            border: none;
            border-radius: 12px;
            color: white;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: transform 0.3s;
        }
        
        .auth-btn:hover {
            transform: translateY(-3px);
        }
        
        .error-message {
            background: rgba(255, 46, 99, 0.2);
            border: 1px solid #ff2e63;
            color: #ff7b9c;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: none;
        }
        
        /* التحميل */
        .loading {
            text-align: center;
            padding: 20px;
            color: #00adb5;
        }
        
        /* التجاوب مع الأجهزة المحمولة */
        @media (max-width: 768px) {
            .header {
                padding: 12px 15px;
            }
            
            .logo h1 {
                font-size: 20px;
            }
            
            .messages-container {
                padding: 15px;
            }
            
            .message {
                max-width: 90%;
            }
            
            .message-image {
                max-width: 200px;
            }
            
            .input-container {
                padding: 15px;
            }
            
            .auth-box {
                width: 95%;
            }
        }
    </style>
</head>
<body>
    <!-- غرفة الدردشة -->
    <div id="chat-container">
        <!-- شريط الرأس -->
        <div class="header">
            <div class="logo">
                <i class="fas fa-comments"></i>
                <h1>مجموعة الدردشة الموحدة</h1>
            </div>
            
            <?php if ($logged_in && $user_data): ?>
            <div class="user-info">
                <img src="<?php echo htmlspecialchars($user_data['profile_image']); ?>" alt="صورة الملف الشخصي" class="profile-img" id="profile-img-btn">
                <span class="display-name"><?php echo htmlspecialchars($user_data['display_name']); ?></span>
                <button class="logout-btn" id="logout-btn"><i class="fas fa-sign-out-alt"></i> خروج</button>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- منطقة عرض الرسائل -->
        <div class="messages-container" id="messages-container">
            <div class="loading" id="loading-messages">
                <i class="fas fa-spinner fa-spin"></i> جاري تحميل الرسائل...
            </div>
        </div>
        <!-- زر التمرير للأسفل -->
<div id="scroll-to-bottom" style="
    position: absolute;
    bottom: 100px;
    right: 30px;
    width: 40px;
    height: 40px;
    background: #00adb5;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    z-index: 90;
    opacity: 0;
    transform: translateY(20px);
    transition: all 0.3s ease;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.3);
">
    <i class="fas fa-arrow-down" style="color: white;"></i>
</div>
        <!-- منطقة إرسال الرسائل -->
        <?php if ($logged_in): ?>
        <div class="input-container">
            <textarea class="message-input" id="message-input" placeholder="اكتب رسالتك هنا... (يدعم العربية والإنجليزية)" rows="1"></textarea>
            <label for="image-upload" class="file-label">
                <i class="fas fa-image"></i>
            </label>
            <input type="file" id="image-upload" accept="image/*" style="display: none;">
            <button class="send-btn" id="send-btn">
                <i class="fas fa-paper-plane"></i>
            </button>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- نافذة الدخول/التسجيل -->
    <div id="auth-overlay">
        <div class="auth-box">
            <div class="auth-header">
                <h2>مرحباً بك في مجموعتنا</h2>
                <p>سجل الدخول أو أنشئ حساباً للانضمام للدردشة</p>
            </div>
            
            <div class="auth-tabs">
                <div class="auth-tab active" data-tab="login">تسجيل الدخول</div>
                <div class="auth-tab" data-tab="signup">إنشاء حساب</div>
            </div>
            
            <!-- نموذج تسجيل الدخول -->
            <div class="auth-form active" id="login-form">
                <div class="error-message" id="login-error"></div>
                <div class="input-group">
                    <label for="login-username"><i class="fas fa-user"></i> اسم المستخدم</label>
                    <input type="text" id="login-username" placeholder="أدخل اسم المستخدم">
                </div>
                <div class="input-group">
                    <label for="login-password"><i class="fas fa-lock"></i> كلمة المرور</label>
                    <input type="password" id="login-password" placeholder="أدخل كلمة المرور">
                </div>
                <button class="auth-btn" id="login-btn">تسجيل الدخول</button>
            </div>
            
            <!-- نموذج إنشاء حساب -->
            <div class="auth-form" id="signup-form">
                <div class="error-message" id="signup-error"></div>
                <div class="input-group">
                    <label for="signup-username"><i class="fas fa-user"></i> اسم المستخدم</label>
                    <input type="text" id="signup-username" placeholder="اختر اسم مستخدم فريد">
                </div>
                <div class="input-group">
                    <label for="signup-displayname"><i class="fas fa-id-card"></i> الاسم الظاهر</label>
                    <input type="text" id="signup-displayname" placeholder="الاسم الذي سيراه الآخرون">
                </div>
                <div class="input-group">
                    <label for="signup-password"><i class="fas fa-lock"></i> كلمة المرور</label>
                    <input type="password" id="signup-password" placeholder="كلمة مرور قوية">
                </div>
                <div class="input-group">
                    <label for="signup-password2"><i class="fas fa-lock"></i> تأكيد كلمة المرور</label>
                    <input type="password" id="signup-password2" placeholder="أعد إدخال كلمة المرور">
                </div>
                <button class="auth-btn" id="signup-btn">إنشاء حساب</button>
            </div>
        </div>
    </div>
    
    <!-- ملف JavaScript -->
    <script>
        // حالة المستخدم من PHP
        const loggedIn = <?php echo $logged_in ? 'true' : 'false'; ?>;
        const userId = <?php echo $logged_in && $user_data ? $user_data['id'] : 'null'; ?>;
        const userDisplayName = "<?php echo $logged_in && $user_data ? htmlspecialchars($user_data['display_name'], ENT_QUOTES) : ''; ?>";
        const userProfileImage = "<?php echo $logged_in && $user_data ? htmlspecialchars($user_data['profile_image'], ENT_QUOTES) : ''; ?>";
    </script>
    <script src="app.js"></script>
<script>
    // منع إعادة التحميل عند ترك التبويب
    let isTabActive = true;
    
    document.addEventListener('visibilitychange', function() {
        isTabActive = !document.hidden;
    });
    
    // تحسين تجربة الهاتف
    if ('ontouchstart' in window) {
        document.body.classList.add('touch-device');
    }
    
    // منع التكبير على الهواتف عند التركيز على الحقول
    document.addEventListener('DOMContentLoaded', function() {
        const viewport = document.querySelector('meta[name="viewport"]');
        if (viewport && /iPhone|iPad|iPod/.test(navigator.userAgent)) {
            viewport.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
        }
    });
    
    // إصلاح مشكلة الارتفاع على المتصفحات المحمولة
    function setFullHeight() {
        const vh = window.innerHeight * 0.01;
        document.documentElement.style.setProperty('--vh', `${vh}px`);
        
        const chatContainer = document.getElementById('chat-container');
        if (chatContainer) {
            chatContainer.style.height = window.innerHeight + 'px';
        }
    }
    
    window.addEventListener('resize', setFullHeight);
    window.addEventListener('orientationchange', setFullHeight);
    setFullHeight();
</script>
</body>
</html>