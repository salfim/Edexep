<?php
$host = 'sql111.ezyro.com';
$dbname = 'ezyro_41026468_cot_db';
$username = 'ezyro_41026468';
$password = 'a2decca79';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->exec("SET NAMES 'utf8mb4';");
    $conn->exec("SET CHARACTER SET utf8mb4;");
    $conn->exec("SET SESSION collation_connection = 'utf8mb4_unicode_ci';");
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>